const PPS_EVAL_CATALOGO = {"GPC":{"instrumento":"IEPP-01-EC","especialidad_criterios":"Gerencia y Producción en Cocina","criterios":["Implementa herramientas tecnológicas para el control de inventarios, pedidos y requisiciones en las áreas operativas.","Organiza las preparaciones previas para elaboraciones de cocina costarricense de vanguardia, según requerimientos de producción y procedimientos de la organización.","Crea productos gastronómicos innovadores de cocina costarricense, según métodos y técnicas de vanguardia, elementos de cocina de autor o fusión y buenas prácticas de manufactura.","Verifica las características sensoriales finales de las elaboraciones culinarias, según ficha técnica.","Realiza el montaje de elaboraciones de cocina costarricense de vanguardia, según técnicas de decoración, normativa vigente y protocolos de la organización.","Organiza la puesta a punto de materias primas para preparaciones de cocina internacional, según requerimientos de producción y procedimientos de la organización.","Aplica técnicas de preparación y cocción propias de la cocina asiática, según el producto por elaborar, ficha técnica y tiempos de servicio.","Aplica técnicas de preparación y cocción propias de la cocina mexicana, según el producto por elaborar, ficha técnica y tipo de servicio.","Aplica técnicas de preparación y cocción propias de la cocina peruana, según el producto por elaborar, ficha técnica y tipo de servicio.","Realiza el montaje de elaboraciones de cocina internacional, según técnicas de decoración, normativa vigente y protocolos de la organización.","Realiza preparaciones previas para productos de pastelería, según formulación, ficha técnica, buenas prácticas de manufactura y normativa vigente.","Elabora productos de pastelería para restauración, eventos o banquetes, según métodos de elaboración, fórmula panadero, ficha técnica y variables del proceso.","Aplica técnicas de decoración de productos de pastelería, según buenas prácticas de manufactura y protocolos de la organización.","Analiza el mercado meta gastronómico, según la proyección de la organización.","Elabora fichas técnicas de la oferta gastronómica, según requerimientos de la organización y normativa vigente.","Costea la oferta gastronómica, según fichas técnicas, requerimientos de la organización y normativa vigente.","Establece el diseño de la oferta gastronómica, según requerimientos de la organización, mercado meta y normativa vigente.","Elabora presupuestos del área de cocina, según requerimientos de la organización.","Realiza un plan para la organización de los procesos del área de cocina, según objetivos de la organización, presupuesto, procesos operativos y recurso humano asignado.","Aplica técnicas de supervisión a procesos de cocina, según protocolos de la organización."]},"CSO":{"instrumento":"IEPP-01-EC","especialidad_criterios":"Configuración y Soporte a Redes de Comunicación y Sistemas Operativos (EC)","criterios":["Diferencia los tipos de software utilizados por la computadora de conformidad con el entorno empresarial.","Aplica normas técnicas en la construcción y reposición de sistemas de cableado estructurado, según el contexto empresarial.","Instala y configura componentes de hardware y software en las computadoras, aplicando las medidas de seguridad informática según el entorno empresarial.","Programa componentes de software utilizando programación interpretada multiparadigma, según el contexto empresarial.","Aplica técnicas de reparación de computadoras portátiles, aplicando principios de servicio al cliente y salud e higiene ocupacional, según contexto empresarial.","Aplica mantenimiento y reparación de dispositivos periféricos, aplicando principios de servicio al cliente y de salud e higiene ocupacional, según contexto empresarial.","Instala sistemas operativos y software especifico en diferentes tipos de servidores, según contexto empresarial.","Aplica herramientas y estrategias que garanticen el manejo seguro de la información, según el contexto o entorno empresarial.","Configura redes de computadoras, aplicando las medidas de seguridad informática que el contexto empresarial establezcan.","Configura redes de área local, utilizando los fundamentos de enrutamiento y conmutación de redes de datos, así como los protocolos de redes pequeñas y grandes, conforme con el contexto empresarial.","Diseña redes cumpliendo los parámetros solicitados, aplicando servicios de enmascaramiento de direcciones IP, calidad de servicios, virtualización y automatización de redes, según el contexto empresarial.","Programa componentes de software para la programación de entornos de redes de área local, según el contexto empresarial.","Aplica elementos relacionados con el manejo de información dirigido a la construcción y mantenimiento de bases de datos, haciendo uso de lenguajes de programación, según el contexto empresarial.","Utiliza elementos y principios de la estadística en la representación de datos, para la toma de decisiones, según el contexto empresarial.","Configura sistemas operativos de código abierto y software licenciado, aplicando procesos avanzados de configuración, según el contexto empresarial.","Configura sistemas operativos de red, administrando cuentas, grupos, funciones de impresión, procesos de mejoramiento del rendimiento y optimización, seguridad y funciones de auditoría, aplicando mandatos nativos, según el contexto empresarial.","Monitorea software malicioso que afecte el funcionamiento de los activos informáticos, mediante la implementación de medidas preventivas y herramientas antimalware, según el contexto empresarial.","Analiza los ataques que se presentan en los dispositivos IoT, utilizando herramientas de seguridad de internet de las cosas (IoT) para la evaluación de los sistemas, según el contexto empresarial.","Utiliza las herramientas de red y orquestación para el monitoreo integral del ecosistema tecnológico, según el contexto empresarial."]},"CCI":{"instrumento":"IEPP-01-EC","especialidad_criterios":"Contabilidad y Control Interno (EC)","criterios":["Calcula operaciones matemáticas-financieras relacionadas con interés simple, interés compuesto y descuentos, utilizando la hoja electrónica o software específico según corresponda.","Registra contablemente los asientos de diario, de ajuste y de cierre para los diferentes tipos de empresas (servicios, comercial y manufacturera), utilizando la hoja electrónica o software específico según corresponda.","Elabora comprobantes electrónicos y documentos comerciales según lo tipifica el Ministerio de Hacienda y el Código de Comercio, utilizando el software del Ministerio de Hacienda u otros tipos de software específico.","Aplica la gestión documental, según la normativa emanada por Archivo Nacional, utilizando herramientas tecnológicas.","Elabora ciclos contables de las empresas comerciales y de las empresas de servicios, utilizando software específico.","Registra contablemente el impuesto al valor agregado (IVA), el impuesto sobre la renta y el impuesto al salario, utilizando la hoja electrónica o software específico según corresponda.","Aplica la Ley de Fortalecimiento de las Finanzas Pública, en operaciones comerciales y contables.","Implementa procedimientos de auditoría y control interno a las cuentas de los estados financieros.","Emplea la plataforma tecnológica, que conecta a las distintas entidades del Sistema Financiero Nacional y el Ministerio de Hacienda.","Aplica la normativa legal del mercado de seguros y del mercado de pensiones, según corresponda.","Resuelve casos relacionados con el mercado de seguros y el mercado de pensiones, aplicando la normativa vigente.","Propone y evalúa proyectos, utilizando sistemas de administración de proyectos.","Confecciona los papeles de trabajo de la Auditoría Operacional, utilizando herramientas tecnológicas.","Contabiliza las operaciones comerciales de las agencias y sucursales, utilizando utilizando la hoja electrónica o software específico según corresponda.","Contabiliza las operaciones de una cooperativa y una asociación solidarista, utilizando la hoja electrónica o software específico según corresponda.","Emite conclusiones y recomendaciones a partir del análisis de los estados financieros y la estadística.","Elabora presupuestos según la normativa vigente, utilizando la hoja electrónica o software específico según corresponda.","Contabiliza los costos por órdenes específicas y por procesos continuos departamentales, utilizando la hoja electrónica o software específico según corresponda.","Desarrolla el punto de equilibrio y el apalancamiento financiero, utilizando la hoja electrónica o software específico según corresponda.","Utiliza el control financiero de los fondos de capitalización y fideicomisos."]},"ALD":{"instrumento":"IEPP-01","especialidad_criterios":"Administración, Logística y Distribución","criterios":["Utiliza los protocolos empresariales relativas a la Administración de Operaciones.","Utiliza el  software de la empresa para administrar proyectos, empleando los protocolos establecidos","Utiliza estrategias de operación en la planta, según los procedimientos de la empresa.","Interpreta la pronósticos empresariales, con el fin de hacer recomendaciones desde la óptica logística.","Administra los inventarios, usando los protocolos de la empresa.","Utitliza un software de control estadístico relativo a procesos empresariales y de planta.","Verifica la correcta planeación operativa de la capacidad  de manufactura de la planta.","Diseña el trabajo de operación de planta, según los protocolos de la empresa.","Realiza mediciones de trabajo necesarias en la operación de planta.","Administra la bodega, según los protocolos de la empresa.","Aplica las normas de salud ocupacional en la empresa durante el desarrollo de sus funciones profesionales.","Realiza sus funciones, previniendo la legitimación de capitales.","Utiliza las Tecnologías de Información y Comunicación en la ejecución de sus funciones.","Verifica la correcta clasificación arancelaria de las mercancías.","Utiiza los protocolos de la empresa para el trámite documental aduanero correcto.","Utiliza software específicos en trámites aduaneros.","Verifica el cálculo correcto por concepto de seguros, fletes y transportes internacionales.","Administra la cadena de suministros, considerando los estándares de la empresa.","Realiza sus funciones, considerando las disposiciones del CAUCA, RECAUCA, la Ley General de Aduanas y su reglamento versiones vigentes.","Comunica información oral y escrita en inglés y español."]},"ECSC":{"instrumento":"IEPP-01-EC","especialidad_criterios":"Ejecutivo Comercial y de Servicio al Cliente (EC)","criterios":["Procesa información de los clientes, utilizando  tecnologías de la información y comunicación","Desempeña con calidad las funciones en plataformas de servicio, en idioma español o en un segundo idioma","Atiende al cliente interno y externo, aplicando las técnicas de servicio.","Aplica herramientas de mercadeo digital para la recolección de información, identificando oportunidades de negocios y marketing, según las nuevas tendencias.","Utiliza lenguaje comercial,  administrativo y social para comunicarse con clientes, compañeros y jefaturas.","Completa documentos relacionados con tramitología a nivel nacional e internacional según protocolos costarricenses y haciendo uso de herramientas tecnológicas, según corresponda.","Organiza y participa en reuniones, seminarios, eventos, actividades y viajes corporativos de la organización, aplicando normas de etiqueta y protocolo.","Utiliza equipo tecnológico en el quehacer comercial y de servicios según los requerimientos de la organización.","Aplica técnicas para la resolución de problemas considerando aspectos del servicio al cliente, el tipo de persona, su condición o necesidades específicas.","Aplica los principios de relaciones públicas en el trabajo en equipo y actividades corporativas realizadas en la organización.","Redacta documentos comerciales, administrativos, personales, sociales y legales utilizando vocabulario especializado y las técnicas de redacción, ortografía y puntuación vigentes.","Digita textos, cartas, documentos sociales, comerciales, administrativos y legales, aplicando las técnicas de presentación de documentos de forma eficaz y eficiente, según requerimientos organizacionales.","Utiliza las herramientas de la hoja electrónica para la organización e interpretación de datos, la creación de  tablas, cuadros, gráficos y otros, de conformidad con los requerimientos de la organización.","Elabora presentaciones digitales según los requerimientos del contexto, haciendo uso de herramientas tecnológicas.","Diseña composiciones visuales como folletos, tarjetas, calendarios, boletines, diplomas, formularios, invitaciones y páginas web de negocios.","Demuestra competencias para el acceso de información en internet de forma segura, verificando datos en buscadores y utilizando métodos de discriminación y confiabilidad de las fuentes.","Realiza acciones que apoyan la gestión de recursos humanos, según los requerimientos de la empresa y lo establecido en  la legislación vigente.","Aplica los procedimientos para recepción, distribución, envío, seguimiento,  control y transferencia de los documentos de la oficina en soporte físico o electrónico, de acuerdo con la estructura organizacional y la legislación vigente.","Aplica procedimientos de calidad para la asesoría al cliente en forma presencial o remota."]},"ELECTRO":{"instrumento":"IEPP-01","especialidad_criterios":"Electromecánica","criterios":["Realiza trabajos de mantenimeinto correctivo y preventivo en circuitos eléctricos de corriente directa respetando los códigos, reglamentos vigentes y disposiciones de salud ocupacional.","Resuelve las fallas, en circuitos eléctricos de  corriente alterna, respetando los reglamentos y códigos vigentes.","Realiza mediciones de las diferentes magnitudes eléctricas y mecánicas, en forma segura y con los estándares de calidad según los procedimeintos establecidos a nivel empresarial y o estándares nacionales.","Diagnostica averías en circuitos electrónicos básicos, analógicos y digitales siguiendo los protocolos de seguridad y calidad  estabecidos por la empresa.","Repara averías en circuitos electrónicos básicos, analógicos y digitales siguiendo los protocolos de seguridad y calidad  estabecidos por la empresa.","Realiza trabajos de reparación en redes de corriente eléctrica respetando los códigos, reglamnetos vigentes y disposiciones de salud ocupacional.","Construye instalaciones eléctricas residenciales, telefónicas y sistemas electromecánicos, respetando los códigos y reglamentos vigentes en Costa Rica, guardando los lineamientos de seguridad y salud ocupacional.","Brinda mantenimiento preventivo y correctivo de equipos electromecánicos, sistemas de protección contra sobrecargas y corto circuito en instalaciones eléctricas, respetando protocolos y regulaciones vigentes.","Interpreta simbología, esquemas, diagramas y planos de sistemas electromecánicos.","Brinda soporte técnico a sistemas de mando, control y de regulación de máquinas eléctricas basados en elementos electromecánicos, respetando preservando los protocolos de seguridad y calidad vigentes.","Brinda Mantenimiento correctivo y preventivo a sistemas  de circuitos de control y regulación para máquinas eléctricas, construidos a base de dispositivos electrónicos de estado sólido, preservando los protocolos de seguridad y calidad vigentes.","Elabora diseños básicos de sistemas a contactores, aplicados al arranque, mando y regulación de máquinas eléctricas, atendiendo las normativas de calidad y seguridad vigentes, sin dejar de la lado la sotenibilidad ambiental implicada en el buen uso de los recursos.","Interpreta diagramas y datos técnicos de sistemas aplicados al arranque, mando y regulación de máquinas eléctricas normados por los protocolos internacionales y nacionales.","Brinda soporte técnico a los diferentes tipos de máquinas eléctricas según sus características: motores trifásicos, monofásicos y transformadores, guardando las cosideraciones de seguridad y salud ocupacional, así como la sostenibilidad ambiental.","Realiza control de procesos industriales por medio de PLC´s, respetando las normas de seguridad y salud ocupacional.","Da seguimiento a programas de mantenimiento a sistemas electromecánicos, mecánicos hidráulicos y neumáticos empelando herramientas tecnológicas.","Desarrolla procesos de mecánica de banco que generan mejoras en el funcionamiento de los equipos de la planta de producción de la emprea, sin sacrificar la seguridad, la calidad y sostenibilidad ambiental.","Desarrolla procesos de soldadura  electrica y oxiacetilénica que garanticen la mejora en la calidad del funcionamiento de los equipos de la planta de producción de la emprea, de una forma segura y que guarde  los protocolos de calidad y sostenibilidad ambiental.","Desarrolla labores de implementación, mantenimeinto preventivo y correctivo en los controladores de velocidad de las máquinas eléctricas por intermedio de  variadores de frecuencia según los protocolos de seguridad y calidad atinentes a este tipo de labor.","Comunica información oral y escrita en inglés y español."]},"AGROECO":{"instrumento":"IEPP-01","especialidad_criterios":"Agroecología","criterios":["Ejecuta programas que contribuyan a la disminución del impacto ambiental en fincas agropecuarias.","Aplica  prácticas de conservación de cuencas hidrográficas , de acuerdo con las condiciones agroclimaticas de la zona.","Realiza levantamientos topográficos utilizando las herramientas y equipos necesarios.","Utiliza equipos de agrometeorología, en la medición de condiciones agroclimaticas de la zona.","Ejecuta actividades  de conservación de los recursos naturales, de acuerdo con los programas establecidos.","Implementa programas de inocuidad en una explotación agroecológica.","Aplica  métodos de control de enfermedades en cultivos agrícolas, incorporando criterios de  protección del medio ambiente.","Ejecuta prácticas de agroforesteria , conservando el medio ambiente.","Desarrolla actividades de conservación de suelos, tomando en cuenta las necesidades de la zona.","Reproduce plantas de interés comercial mediante tecnicas agronómicas óptimas.","Aplica técnicas de manejo de especies acuícolas,  tomando en cuenta los requerimientos necesarios.","Ejecuta prácticas de manejo de bosques, tomando en cuenta la conservación de recursos naturales.","Ejecuta actividades de manejo en una explotación de animales domésticos, utilizando sistemas de producción sostenible.","Ejecuta prácticas de manejo en cultivos agrícolas, tomando en cuenta los requerimientos necesarios.","Aplica técnicas de manejo en un zoocriadero,  tomando en cuenta los requerimientos óptimos.","Establece proyectos de agro ecología,  utilizando tecnologias de información y comunicación.","Administra fincas agroecológicas, tomando en cuenta los principios administrativos.","Elabora análisis  económicos en proyectos agroecológicos de interés comercial.","Aplica conceptos de cultura de la calidad, en los  procesos productivos.","Utiliza herramientas en el campo agroecológico, tomando en cuenta las normas de seguridad."]},"AATP":{"instrumento":"IEPP-01","especialidad_criterios":"Agroindustria Alimentaria con Tecnología Pecuaria","criterios":["Ejecuta prácticas de conservación de la leche tomando en cuenta aspectos de inocuidad de alimentos.","Elabora embutidos, tomando en cuenta las técnicas modernas de producción.","Produce diferentes tipos de helados, aplicando técnicas modernas de producción.","Construye  programas de inocuidad en los procesos de industrialización de alimentos.","Ejecuta prácticas de conservación de carnes, tomando en cuenta aspectos de inocuidad de alimentos.","Elabora derivados lácteos , aplicando normas de inocuidad  en los procesos productivos.","Elabora diferentes tipos de quesos aplicando normas de inocuidad en los procesos productivos.","Ejecuta actividades  de mantenimiento de equipos agroindustriales, de acuerdo con los programas establecidos.","Desarrolla proyectos agroindustriales, utilizando herramientas informáticas.","Administra proyectos agroindustriales, tomando en cuenta los principios administrativos.","Construye protocolos para la desinfección de distintas areas de los talleres agorindustriales.","Ejecuta actividades de desinfeción de talleres agroindustriales, de acuerdo con los protocolos establecidos.","Elabora análisis  económicos en proyectos agroindustriales de interés comercial.","Establece proyectos de agro industria,  utilizando tecnologias de información y comunicación.","Aplica conceptos de cultura de la calidad, en los  procesos productivos.","Utiliza el análisis FODA para la identificación de oportunidades de negocios en el campo agro industrial.","Realiza practicas de laboratorio, que asegurando la calidad de productos agroindustriales.","Aplica criterios de evaluación organoléptica en la calidad de productos agro industriales.","Elabora diagramas de flujo general para la obtención de diferentes tipos de productos agroindustriales.","Utiliza empaques adecuados para  productos agroindustriales, respetando las normas de calidad."]},"PAP":{"instrumento":"IEPP-01-EC","especialidad_criterios":"Producción Agrícola y Pecuaria (EC)","criterios":["Ejecuta buenas prácticas de desarrollo sostenible, en la implementación de proyectos propios de las empresas del ámbito agropecuario.","Ejecuta prácticas de conservación de suelos y su manejo de forma sostenible, considerando los requerimientos de los cultivos.","Aplica fundamentos y técnicas para el manejo y la producción de cultivos en ambientes protegidos y áreas extensivas.","Utiliza equipo y aplicaciones de agricultura de precisión en sistemas agrícolas y pecuarios.","Ejecuta técnicas de establecimiento de sistemas de producción de especies olerícolas, según requerimientos agroecológicos","Aplica métodos de cosecha, clasificación, limpieza, empaque y comercialización de productos de especies olerícolas.","Implementa prácticas de aprovechamiento, procesamiento y preservación de especies forrajeras utilizadas en la nutrición animal.","Aplica técnicas y procedimientos de micropropagación de plantas utilizando equipo de laboratorio, que asegure la producción de conformidad con los estándares de calidad.","Elabora documentos administrativos requeridos en las fincas agropecuarias, haciendo uso de herramientas tecnológicas.","Ejecuta procedimientos para la identifcación de las principales razas y especies de animales, utilizados para la producción de carne, leche y huevos.","Ejecuta prácticas de manejo sanitario en sistemas de producción de carne, leche y huevos; siguiendo protocolos de bienestar animal, bioseguridad, higiene y seguridad ocupacional.","Aplica técnicas para el mejoramiento reproductivo y genético en especies de animales destinados a la producción de leche, carne y huevos; haciendo uso de herramientas tecnológicas.","Utiliza herramientas tecnologicas en las transacciones y actividades requeridas para la operación del negocio que promuevan el mejoramiento en la eficiencia de las empresas agropecuarias.","Ejecuta procedimientos para la identificación de acciones requeridas en programas de carbono neutralidad para la finca agropecuaria.","Identifica los requerimientos edafoclimáticos de los cultivos agrícolas más frecuentes en la finca y su alrededores.","Identifica las principales plagas y enfermedades que afectan los cultivos agrícolas presentes la finca agrícola y alrededores.","Ejecuta prácticas de preparación de terreno, propagación, siembra, fertilización, control de  malezas, poda y riego requeridos en el manejo de los cultivos agícolas.","Aplica métodos de cosecha y post cosecha en sistemas de producción de cultivos agrícolas, según requerimientos de mercado y haciendo uso de la tecnología.","Aplica prácticas de manejo para la instalación y manejo de especies animales no tradicionales (apícultura, equinos, entre otros) considerando sus requerimientos y etapas, según corresponda."]},"OEA":{"instrumento":"IEPP-01-EC","especialidad_criterios":"Operaciones en Empresas de Alojamiento (EC)","criterios":["Implementa buenas prácticas al prestar servicios turísticos, tomando en consideración los deberes y obligaciones desde el ámbito de la ética profesional.","Atiende la recepción del hotel, aplicando los principios del servicio al cliente, protocolos y estándares de calidad establecidos.","Aplica aspectos técnicos en el manejo de puntos del front office del hotel, de conformidad con las normas internacionales de servicio al cliente.","Ejecuta protocolos de atención en materia de traslado y embalaje de equipaje de los huéspedes de hotel, según estándares de calidad superior y normas de salud ocupacional.","Ejecuta funciones de Concierge, durante la prestación de servicios especializados aplicando los protocolos en hoteles de alta calidad, según estándares internacionales.","Realiza reservas aplicando los protocolos de atención al cliente, utilizando herramientas tecnológicas.","Coordina con los departamentos del hotel,  aspectos técnicos propios del quehacer de turno.","Aplica protocolos y procedimientos técnicos relacionados con el servicio al cliente de hotel.","Aplica técnicas orientadas al entretenimiento del cliente en hoteles de clase superior, de acuerdo con las normas de salud ocupacional.","Aplica técnicas e instrumentos para la recolección de la información, orientada a la búsqueda del bienestar del huésped durante la estadía de hotel, según normas internacionales.","Implementa protocolos de limpieza y desinfección para las habitaciones de hotel y áreas comunes, con base en las normas internacionales y las políticas organizacionales.","Ejecuta acciones para el cumplimiento de las labores y controles establecidos en la atención y el funcionamiento de: habitaciones, áreas públicas, suministros de insumos, trámite de averías, desperdicios e inventarios del departamento de ama de llaves del hotel, haciendo uso de recursos tecnológicos e instrumentos de control, según protocolos y políticas organizacionales.","Aplicar técnicas para el desarrollo de diseños básicos, elaboración de arreglos florales y decoración interna de espacios en empresas de alojamiento.","Aplicar técnicas para la preparación, tratamiento y lavado de ropa en hoteles, según protocolos establecidos y políticas organizacionales.","Aplicar técnicas dirigidas al entretenimiento de los turistas de las empresas de alojamiento, considerando las normas de seguridad y salud ocupacional.","Desarrollar ejercicios físicos en tierra y agua para el entretenimiento de los turistas del hotel, con base en estándares nacionales y normas de salud ocupacional.","Generar rutinas de ejercicios físicos que promuevan la inclusión de huéspedes con algún tipo de discapacidad."]}};


const PPS_EVAL_HEADERS=['ID_EVALUACION','ID_ASIGNACION','ID_ESTUDIANTE','CODIGO_ESPECIALIDAD','INSTRUMENTO','NUMERO_EVALUACION','ID_DOCENTE','NOMBRE_DOCENTE','ESTADO','RESPUESTAS_JSON','PUNTOS_OBTENIDOS','PUNTOS_POSIBLES','PORCENTAJE_REFERENCIAL','FECHA_GUARDADO'];


const PPS_V11_EXTRA=['FIRMA_JSON','NOMBRE_FIRMANTE','FECHA_FIRMA','ORIGEN'];

function myFunction() {}

const PPS_EVAL_GENERICOS_2026=['Utiliza herramientas y tecnologias digitales','Compromiso con el ambiente y la sostenibilidad','Salud e higiene ocupacional','Calidad en la ejecucion de tareas','Mantenimiento preventivo y correctivo','Procesador de textos','Hoja electronica','Presentaciones digitales','Proteccion e integridad de la informacion','Documentos en la nube','Interpretacion de informacion tecnica','Etiqueta y protocolo','Comunicacion oral en ingles','Comunicacion escrita en ingles','Comprension de manuales en ingles','Comprension de conversaciones e instrucciones en ingles'];
const PPS_EVAL_DESARROLLO_HUMANO_2026=['Autocontrol','Autoaprendizaje','Comunicacion oral y escrita','Comunicacion asertiva','Capacidad de negociacion','Compromiso etico','Discernimiento y responsabilidad','Innovacion y creatividad','Juicio y toma de decisiones','Liderazgo','Solucion de problemas','Orientacion y servicio al cliente','Proactividad','Pensamiento critico','Trabajo en equipo'];
function ppsEvalCriterios_(codigo){var base=PPS_EVAL_CATALOGO[codigo]&&Array.isArray(PPS_EVAL_CATALOGO[codigo].criterios)?PPS_EVAL_CATALOGO[codigo].criterios:[];return base.concat(PPS_EVAL_GENERICOS_2026.map(function(x){return 'COMPETENCIAS GENERICAS - '+x;}),PPS_EVAL_DESARROLLO_HUMANO_2026.map(function(x){return 'COMPETENCIAS PARA EL DESARROLLO HUMANO - '+x;}));}


function ppsEvalHoja_(){

 const ss=ssDocPPS_();let sh=ss.getSheetByName(PPS_STAGE_TAB);

 if(!sh)sh=ss.insertSheet(PPS_STAGE_TAB);

 if(sh.getLastRow()===0)sh.appendRow(PPS_EVAL_HEADERS);

 else {const hs=sh.getRange(1,1,1,PPS_EVAL_HEADERS.length).getDisplayValues()[0];if(PPS_EVAL_HEADERS.some((x,i)=>hs[i]!==x))throw new Error('La hoja EVALUACIONES_DOCENTES_2026 no tiene los encabezados esperados.');}

 return sh;

}


function ppsEvalRegistros_(idAsignacion){

 const sh=ppsEvalHoja_(),d=sh.getDataRange().getDisplayValues(),hs=d[0];

 return d.slice(1).map((r,i)=>{const o={};hs.forEach((k,n)=>o[k]=r[n]);o._fila=i+2;return o;}).filter(x=>x.ID_ASIGNACION===String(idAsignacion));

}


function apiAbrirEvaluacionPPS(token,idAsignacion,numero,codigoSeleccionado){

 const n=Number(numero);if(n!==1&&n!==2)throw new Error('Número de evaluación inválido.');

 const q=ppsEvalAcceso_(token,idAsignacion,codigoSeleccionado,false);

 const item=ppsEvalRegistros_(idAsignacion).find(x=>Number(x.NUMERO_EVALUACION)===n);

 let respuestas={};try{respuestas=JSON.parse(item&&item.RESPUESTAS_JSON||'{}')}catch(e){}

 return {ok:true,numero:n,idAsignacion:String(idAsignacion),estudiante:String(q.a.obj.NOMBRE_COMPLETO||''),codigo:q.codigo,

   instrumento:PPS_EVAL_CATALOGO[q.codigo].instrumento,criterios:ppsEvalCriterios_(q.codigo),

   respuestas:respuestas,estado:item?item.ESTADO:'Sin iniciar',porcentajeReferencial:item?item.PORCENTAJE_REFERENCIAL:'',

   empresa:String(q.a.obj.EMPRESA||''),firma:item&&item.FIRMA_JSON?JSON.parse(item.FIRMA_JSON):null,firmante:item?item.NOMBRE_FIRMANTE||'':'',fechaFirma:item?fechaTextoDocPPS_(item.FECHA_FIRMA):'',puedeGuardar:!q.c.demo,demo:!!q.c.demo};

}


function apiGuardarEvaluacionFirmadaPPS(token,idAsignacion,numero,codigo,respuestas,finalizar,firma){
 const n=Number(numero);if(n!==1&&n!==2)throw new Error('Evaluación inválida.');
 const q=ppsEvalAcceso_(token,idAsignacion,codigo,true);
 return ppsV11Guardar_(q,idAsignacion,n,respuestas,!!finalizar,firma,'PWA','');
}

function ppsV11Hoja_(nombre,headers){
 const ss=ssDocPPS_();let h=ss.getSheetByName(nombre);
 if(!h){h=ss.insertSheet(nombre);h.appendRow(headers);}
 const actuales=h.getRange(1,1,1,Math.max(h.getLastColumn(),1)).getDisplayValues()[0];
 headers.forEach((v,i)=>{if(actuales[i]&&actuales[i]!==v)throw new Error('Encabezados incompatibles en '+nombre);if(!actuales[i])h.getRange(1,i+1).setValue(v);});
 return h;
}

function ppsV11Firma_(f,requerida){
 if(!f){if(requerida)throw new Error('Debe indicar el nombre del firmante y dibujar su firma.');return null;}
 const nombre=String(f.nombre||'').trim();
 if(nombre.length<3||nombre.length>160)throw new Error('Indique el nombre completo del firmante.');
 const trazos=f.trazos;
 if(!Array.isArray(trazos)||!trazos.length||trazos.length>100)throw new Error('Dibuje su firma en el recuadro.');
 let total=0,distancia=0;
 const limpios=trazos.map(t=>{
  if(!Array.isArray(t)||t.length<2||t.length>2000)throw new Error('Firma inválida.');
  total+=t.length;
  return t.map((p,i)=>{
   if(!Array.isArray(p)||p.length!==2||p.some(n=>typeof n!=='number'||!isFinite(n)||n<0||n>1))throw new Error('Firma inválida.');
   if(i)distancia+=Math.hypot(p[0]-t[i-1][0],p[1]-t[i-1][1]);
   return p.map(n=>Math.round(n*10000)/10000);
  });
 });
 if(total>3000||total<3||distancia<0.02)throw new Error('La firma está vacía o es demasiado breve. Dibújela nuevamente.');
 const json=JSON.stringify({v:1,trazos:limpios});
 if(json.length>44000)throw new Error('La firma es demasiado extensa; límpiela e intente nuevamente.');
 return {nombre:nombre,json:json};
}

function ppsV11Calcular_(criterios,respuestas,finalizar){
 if(!respuestas||typeof respuestas!=='object'||Array.isArray(respuestas))throw new Error('Respuestas inválidas.');
 const limpias={};let puntos=0,posibles=0;
 criterios.forEach((_,i)=>{
  const v=respuestas[String(i)];if(v===undefined||v===null||v==='')return;
  if(!['0','1','2','NA'].includes(String(v)))throw new Error('Valor inválido en el criterio '+(i+1));
  limpias[String(i)]=String(v);
  if(String(v)!=='NA'){puntos+=Number(v);posibles+=2;}
 });
 if(finalizar&&Object.keys(limpias).length!==criterios.length)throw new Error('Complete todos los criterios o marque No aplica antes de enviar.');
 if(finalizar&&!posibles)throw new Error('No puede finalizar con todos los criterios No aplica.');
 return {respuestas:limpias,puntos:puntos,posibles:posibles,nota:posibles?Math.round(10000*puntos/posibles)/100:null};
}

function ppsV11Guardar_(q,idAsignacion,n,respuestas,finalizar,firma,origen,enlaceHash){
 if(q.c.demo)throw new Error('El perfil de demostración no guarda registros reales.');
 const cal=ppsV11Calcular_(ppsEvalCriterios_(q.codigo),respuestas,finalizar);
 const f=ppsV11Firma_(firma,!!finalizar&&n===2);
 const lock=LockService.getScriptLock();lock.waitLock(20000);
 try{
  if(enlaceHash)ppsV11EnlaceContexto_(enlaceHash,true);
  const previo=ppsEvalRegistros_(idAsignacion).find(x=>Number(x.NUMERO_EVALUACION)===n);
  if(previo&&previo.ESTADO==='Finalizada')throw new Error('La evaluación ya está finalizada y no puede sobrescribirse.');
  const seg=objsPPS_(PPS26_DOCENTE_CFG_V3.SEG).find(x=>String(x.ID_ASIGNACION)===String(idAsignacion)&&normPPS_(x.ESTADO)==='activo');
  if(!seg||String(seg.ID_DOCENTE_SEGUIMIENTO)!==String(q.c.idDocente))throw new Error('El seguimiento ya no corresponde al docente responsable.');
  const id=previo?previo.ID_EVALUACION:'EV-'+Utilities.getUuid(),ahora=new Date();
  const fila=[id,String(idAsignacion),String(q.a.obj.ID_ESTUDIANTE||''),q.codigo,PPS_EVAL_CATALOGO[q.codigo].instrumento,n,
    String(q.c.idDocente),String(q.c.nombre||''),finalizar?'Finalizada':'Borrador',JSON.stringify(cal.respuestas),
    cal.puntos,cal.posibles,cal.nota===null?'':cal.nota,ahora,
    f?f.json:(previo&&previo.FIRMA_JSON||''),f?f.nombre:(previo&&previo.NOMBRE_FIRMANTE||''),
    f?ahora:(previo&&previo.FECHA_FIRMA||''),origen||'PWA'];
  const h=ppsV11Hoja_(PPS_STAGE_TAB,PPS_EVAL_HEADERS.concat(PPS_V11_EXTRA));
  // Comprobar el seguimiento antes del guardado; nunca sustituir una fila finalizada.
  if(finalizar)bloquearSeguimientoPorEvaluacionPPS_(idAsignacion,id,q.c.idDocente);
  if(previo)h.getRange(previo._fila,1,1,fila.length).setValues([fila]);else h.appendRow(fila);
  if(enlaceHash&&finalizar){
   const z=ppsV11Leer_('EVALUACIONES_ENLACES_2026').find(x=>x.obj.HASH===enlaceHash);
   if(z){const eh=ssDocPPS_().getSheetByName('EVALUACIONES_ENLACES_2026');eh.getRange(z.rowIndex,7).setValue('Utilizado');}
  }
  return {ok:true,estado:finalizar?'Finalizada':'Borrador',porcentajeReferencial:cal.nota,mensaje:finalizar?'Evaluación firmada, enviada y guardada.':'Borrador guardado.'};
 }finally{lock.releaseLock();}
}
/* Solo para el proyecto de pruebas existente. No incluir en producción. */
const PPS_STAGE_PROJECT = '1nGQjNeAKJMtTBizaYU2u0C09SkS_pVEynW0dIcLJlcT6rroZfXNg80fu';
const PPS_STAGE_DB = '13BR0o0yOOazet5sui4I7vpmMkaNUYLt8Lj8YJNi3YFA';
const PPS_STAGE_TAB = 'PPS_AUTOGUARDADO_PRUEBAS_2026';
const PPS_STAGE_PREFIX = 'ASG-PRUEBA-GUARDADO-';
const PPS26_DOCENTE_CFG_V3 = {SEG: 'SEGUIMIENTO_SINTETICO'};
function ppsStageAssert_(){
 if(ScriptApp.getScriptId()!==PPS_STAGE_PROJECT)throw new Error('Bloqueado: proyecto distinto del entorno aislado.');
 if(PPS_STAGE_DB!=='13BR0o0yOOazet5sui4I7vpmMkaNUYLt8Lj8YJNi3YFA')throw new Error('Bloqueado: base de pruebas inesperada.');
 if(Session.getEffectiveUser().getEmail().toLowerCase()!=='cordiempresactpl@gmail.com')throw new Error('Abra la prueba con la cuenta de coordinación autorizada.');
}
function doGet(){
 ppsStageAssert_();
 return HtmlService.createHtmlOutputFromFile('PruebaGuardado').setTitle('PPS2026 — prueba real de guardado AISLADA');
}
function ssDocPPS_(){ppsStageAssert_();return SpreadsheetApp.openById(PPS_STAGE_DB);}
function normPPS_(v){return String(v||'').trim().toLowerCase();}
function fechaTextoDocPPS_(v){return v instanceof Date?Utilities.formatDate(v,'America/Costa_Rica','dd/MM/yyyy HH:mm'):String(v||'');}
function ppsStageSession_(token){
 ppsStageAssert_();
 if(!/^[a-f0-9]{64}$/.test(String(token||'')))throw new Error('Sesión de prueba inválida.');
 const raw=CacheService.getScriptCache().get('pps_stage_'+token);
 if(!raw)throw new Error('La sesión de prueba expiró. Ingrese de nuevo.');
 const value=JSON.parse(raw);
 if(!String(value.id).startsWith(PPS_STAGE_PREFIX))throw new Error('El expediente no es ficticio.');
 return value;
}
function ppsStageCaso_(token){
 const state={id:PPS_STAGE_PREFIX+Utilities.getUuid(),codigo:'AGROECO'};
 CacheService.getScriptCache().put('pps_stage_'+token,JSON.stringify(state),1800);
 // Registro sintético mínimo para que el guardado original compruebe seguimiento.
 const props=PropertiesService.getScriptProperties();
 props.setProperty(state.id,JSON.stringify({ID_ASIGNACION:state.id,ESTADO:'Activo',ID_DOCENTE_SEGUIMIENTO:'DOC-PRUEBA-GUARDADO'}));
 return state;
}
function ppsStageLogin(){
 ppsStageAssert_();
 // Google autentica al propietario del despliegue privado. El rol docente es ficticio.
 const token=Array.from({length:4},()=>Utilities.getUuid().replace(/-/g,'')).join('').slice(0,64);
 const state=ppsStageCaso_(token);
 return {ok:true,token:token,idAsignacion:state.id,codigo:state.codigo,entorno:'PRUEBAS_AISLADAS',usuario:'Profesor DEMO de pruebas'};
}
function ppsStageNuevoCaso(token){ppsStageSession_(token);const s=ppsStageCaso_(token);return {ok:true,idAsignacion:s.id,codigo:s.codigo};}
function ppsEvalAcceso_(token,id,codigo,escritura){
 const state=ppsStageSession_(token);
 if(String(id)!==state.id||String(codigo)!=='AGROECO')throw new Error('Solo está permitido el expediente ficticio de esta sesión.');
 return {codigo:'AGROECO',a:{obj:{ID_ASIGNACION:state.id,ID_ESTUDIANTE:'EST-PRUEBA-GUARDADO',NOMBRE_COMPLETO:'Estudiante ficticio de guardado',EMPRESA:'Empresa ficticia'}},c:{idDocente:'DOC-PRUEBA-GUARDADO',nombre:'Profesor DEMO de pruebas',codigoEspecialidad:'AGROECO',demo:false}};
}
function objsPPS_(nombre){
 ppsStageAssert_();if(nombre!==PPS26_DOCENTE_CFG_V3.SEG)throw new Error('Lectura fuera del seguimiento sintético bloqueada.');
 const props=PropertiesService.getScriptProperties().getProperties();
 return Object.keys(props).filter(k=>k.startsWith(PPS_STAGE_PREFIX)).map(k=>JSON.parse(props[k]));
}
function bloquearSeguimientoPorEvaluacionPPS_(id){
 ppsStageAssert_();if(!String(id).startsWith(PPS_STAGE_PREFIX))throw new Error('Asignación no sintética bloqueada.');
 // No se cambia seguimiento real: el bloqueo de edición se valida con ESTADO de la evaluación.
}
function filasObjDocPPS_(hoja){
 ppsStageAssert_();if(hoja.getName()!==PPS_STAGE_TAB)throw new Error('Lectura de otra pestaña bloqueada.');
 const rows=hoja.getDataRange().getValues(),headers=rows.shift()||[];
 return rows.map((r,i)=>({rowIndex:i+2,obj:Object.fromEntries(headers.map((h,j)=>[h,r[j]]))}));
}
function ppsStageVerificar(token,numero){
 const s=ppsStageSession_(token),n=Number(numero);if(n!==1&&n!==2)throw new Error('Número inválido.');
 const h=ssDocPPS_().getSheetByName(PPS_STAGE_TAB);
 const records=h?ppsEvalRegistros_(s.id):[];
 const record=records.find(x=>Number(x.NUMERO_EVALUACION)===n);
 return {ok:true,entorno:'PRUEBAS_AISLADAS',pestana:PPS_STAGE_TAB,idAsignacion:s.id,numero:n,existe:!!record,
  filasDelCaso:records.length,estado:record?record.ESTADO:'Sin guardar',respuestas:record?JSON.parse(record.RESPUESTAS_JSON||'{}'):{},
  nota:record?record.PORCENTAJE_REFERENCIAL:'',firmaRegistrada:!!(record&&record.FIRMA_JSON)};
}
