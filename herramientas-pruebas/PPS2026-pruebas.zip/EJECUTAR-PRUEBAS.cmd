@echo off
cd /d "%~dp0"
node preparar-pruebas.cjs
pause
